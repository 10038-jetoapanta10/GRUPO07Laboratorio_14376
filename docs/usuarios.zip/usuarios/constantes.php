<?php
  define("SERVER","localhost");
  define("USER","root");
  define("PASS","123");
  define("BD","veris");
 ?>